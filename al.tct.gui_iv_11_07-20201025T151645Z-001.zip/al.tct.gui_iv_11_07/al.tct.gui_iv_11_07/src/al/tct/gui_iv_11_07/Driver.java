package al.tct.gui_iv_11_07;

public class Driver {

    public static void main(String[] args) {
        MyFrame frame = new MyFrame();
        frame.setVisible(true);
    }

}
