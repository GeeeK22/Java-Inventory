package al.tct.gui_iv_11_07;

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import javax.swing.event.*;

public class MyFrame extends JFrame {

    private static final int WIDTH = 300;
    private static final int HEIGHT = 500;

    private JPanel mainPanel;

    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenu editMenu;
    private JMenuItem closeMenuItem;
    private JMenuItem genRandColorMenuItem;

    private JSlider redSlider;
    private JSlider greenSlider;
    private JSlider blueSlider;

    private JLabel redLabel;
    private JLabel greenLabel;
    private JLabel blueLabel;

    private JPanel northPanel;
    private JPanel centerPanel;

    public MyFrame() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setSize(WIDTH, HEIGHT);
        setTitle("First GUI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        mainPanel = new JPanel(new BorderLayout());
        northPanel = new JPanel(new GridLayout(3, 2));
        centerPanel = new JPanel();

        menuBar = new JMenuBar();

        fileMenu = new JMenu("File");
        editMenu = new JMenu("Edit");

        closeMenuItem = new JMenuItem("Exit");
        closeMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int status = JOptionPane.showConfirmDialog(
                        MyFrame.this,
                        "Are you sure you want to exit",
                        "",
                        JOptionPane.YES_NO_OPTION);
                if (status == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    dispose();
                }
            }
        });

        genRandColorMenuItem = new JMenuItem("Gen Rand Color");
        genRandColorMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changePanelColor();
            }
        });

//        panel.addMouseListener(new MouseListener() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//            }
//
//            @Override
//            public void mousePressed(MouseEvent e) {
//                panel.setBackground(Color.BLACK);
//            }
//
//            @Override
//            public void mouseReleased(MouseEvent e) {
//                panel.setBackground(Color.WHITE);
//            }
//
//            @Override
//            public void mouseEntered(MouseEvent e) {
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//            }
//        });
        MyChangeListener listener = new MyChangeListener();

        redSlider = new JSlider(0, 255);
        redSlider.addChangeListener(listener);
        greenSlider = new JSlider(0, 255);
        greenSlider.addChangeListener(listener);
        blueSlider = new JSlider(0, 255);
        blueSlider.addChangeListener(listener);

        redLabel = new JLabel("Red");
        greenLabel = new JLabel("Green");
        blueLabel = new JLabel("Blue");

    }

    private void setUI() {
        fileMenu.add(closeMenuItem);
        editMenu.add(genRandColorMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);

        northPanel.add(redLabel);
        northPanel.add(redSlider);
        northPanel.add(greenLabel);
        northPanel.add(greenSlider);
        northPanel.add(blueLabel);
        northPanel.add(blueSlider);

        mainPanel.add(northPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);
        setJMenuBar(menuBar);
    }

    private void changePanelColor() {
        Random rand = new Random();
        int red = rand.nextInt(256);
        int green = rand.nextInt(256);
        int blue = rand.nextInt(256);
        Color c = new Color(red, green, blue);
        centerPanel.setBackground(c);
    }

    private class MyChangeListener
            implements ChangeListener {

        public void stateChanged(ChangeEvent e) {
            int red = redSlider.getValue();
            int blue = blueSlider.getValue();
            int green = greenSlider.getValue();
            centerPanel.setBackground(new Color(red, green, blue));
        }
    }

}
