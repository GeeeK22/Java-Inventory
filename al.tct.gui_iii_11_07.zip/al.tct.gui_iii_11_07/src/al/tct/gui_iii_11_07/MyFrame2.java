package al.tct.gui_iii_11_07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyFrame2 extends JFrame {

    private static final int WIDTH = 400;
    private static final int HEIGHT = 300;

    private JPanel mainPanel;
    private JPanel centerPanel;

    private JButton[] buttons;

    private JButton buttonCall;
    private JButton buttonClear;

    private JTextField result;

    public MyFrame2() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setTitle("SWING Calculator");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        mainPanel = new JPanel(new BorderLayout());
        centerPanel = new JPanel(new GridLayout(4, 3));

        MyActionListener listener = new MyActionListener();
        buttons = new JButton[10];
        for (int i = 0; i <= 9; i++) {
            buttons[i] = new JButton(Integer.toString(i));
            buttons[i].setActionCommand(Integer.toString(i));
            buttons[i].addActionListener(listener);
        }

        result = new JTextField();
        result.setEditable(false);
        result.setComponentOrientation(
                ComponentOrientation.RIGHT_TO_LEFT);

        buttonCall = new JButton("Call");
        buttonCall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (buttonCall.getText().equals("Call")) {
                    buttonCall.setText("Hang up");
                } else {
                    result.setText("");
                    buttonCall.setText("Call");
                }
            }
        });

        buttonClear = new JButton("Clear");
        buttonClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                result.setText("");
//                String s = result.getText();
//                if (!s.isEmpty()) {
//                    result.setText(s.substring(0, s.length() - 1));
//                }
            }
        });
    }

    private void setUI() {

        for (int i = 1; i <= 9; i++) {
            centerPanel.add(buttons[i]);
        }
        centerPanel.add(buttonClear);
        centerPanel.add(buttons[0]);
        centerPanel.add(buttonCall);

        mainPanel.add(result, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    private class MyActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String number = e.getActionCommand();
            result.setText(result.getText() + number);
        }
    }

}
