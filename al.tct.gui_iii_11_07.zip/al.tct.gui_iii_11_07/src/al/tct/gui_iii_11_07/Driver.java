package al.tct.gui_iii_11_07;

public class Driver {

    public static void main(String[] args) {
//        MyFrame frame = new MyFrame();
//        frame.setVisible(true);

//        MyFrame2 frame2 = new MyFrame2();
//        frame2.setVisible(true);
        String name = "Bill Gates";
//        String s = "";
//        s += name.substring(0, 2);
        int indexSpace = name.indexOf(" ");
//        s += name.substring(indexSpace + 1, indexSpace + 3);
//        System.out.println(s);

        byte[] bytes = name.getBytes();
        byte temp = bytes[0];
        bytes[0] = bytes[indexSpace + 1];
        bytes[indexSpace + 1] = temp;
        temp = bytes[1];
        bytes[1] = bytes[indexSpace + 2];
        bytes[indexSpace + 2] = temp;
        System.out.println(new String(bytes));
    }

}
