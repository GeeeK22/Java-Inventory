package al.tct.gui_i_11_07;

import javax.swing.JOptionPane;

public class Driver {

    public static void main(String[] args) {
//        JOptionPane.showMessageDialog(null,
//                "Hello from swing :)", "Title", JOptionPane.PLAIN_MESSAGE);
//
//        JOptionPane.showMessageDialog(null, "Ka viruse", "",
//                JOptionPane.WARNING_MESSAGE);
//        String answer = JOptionPane.showInputDialog("Sa vjec je: ");
//        int mosha = Integer.parseInt(answer);
//        Double.parseDouble(answer);
//        System.out.println(mosha);

        //nese eshte mire te krijohet nje dialog mesazhi dhe te afishohet
        //normalisht
        //nese eshte keq te krijohet nje dialog mesazhi dhe te afishohet
        //si pikepyetje cfare ka
        //nese shkruan dicka tjeter krijoni nje dialog errori ku afishohet
        //nuk e kuptoj cfare do te thuash
//        String answer = JOptionPane.showInputDialog("Si je");
//
//        if (answer.toLowerCase().contains("mire")) {
//            JOptionPane.showMessageDialog(null, "Me behet qejfi", "",
//                    JOptionPane.PLAIN_MESSAGE);
//        } else if (answer.toLowerCase().contains("keq")) {
//            JOptionPane.showMessageDialog(null, "Cfare ka", "",
//                    JOptionPane.QUESTION_MESSAGE);
//        } else {
//            JOptionPane.showMessageDialog(null, "Nuk te kuptoj", "",
//                    JOptionPane.ERROR_MESSAGE);
//        }
        //*******************************************************************
        //merr moshen e perdoruesit me input. nese eshte >= 18
        //afisho  si dialog qe lejohet te hyje nu klub
        //nese jo afisho qe nuk lejohet te hyje ne klub
        //ne nje isntruksion te vetem
        //int mosha = Integer.parseInt(JOptionPane.showInputDialog("Sa vjec je: "));
//        String answer = JOptionPane.showInputDialog("Sa vjec je: ");
//        int mosha = Integer.parseInt(answer);
//
//        if (mosha >= 18) {
//            JOptionPane.showMessageDialog(null, "Lejohet");
//        } else {
//            JOptionPane.showMessageDialog(null, "Nuk lejohet", "",
//                    JOptionPane.ERROR_MESSAGE);
//        }
        //shtate studente do ju japin piket e provimit nga
        // per rastin e dyte "".split(";")
        //pika a
//        double shuma = 0;
//
//        for (int i = 0; i < 7; i++) {
//            String nota = JOptionPane.showInputDialog("Sa pike more");
//            shuma = shuma + Integer.parseInt(nota);
//        }
//
//        JOptionPane.showMessageDialog(null, "Mesatarja " + (shuma / 7));
        //pika b
//        String answer = JOptionPane.showInputDialog(
//                "Vendos notat te ndara me ; ");
//        String[] notat = answer.split(";");
//        double shuma = 0;
//
//        for (int i = 0; i < notat.length; i++) {
//            shuma = shuma + Integer.parseInt(notat[i]);
//        }
//
//        final int nrStudents = notat.length;
//        String message = "Mesatarja e " + nrStudents + " studenteve eshte: "
//                + (shuma / nrStudents);
//
//        JOptionPane.showMessageDialog(null, message);
//        int ans = JOptionPane.showConfirmDialog(null, "A ben ftohte sot", "",
//                 JOptionPane.YES_NO_OPTION);
//
//        if (ans == JOptionPane.OK_OPTION) {
//            System.out.println("Cfare po thua, sot eshte vape.");
//        } else if (ans == JOptionPane.NO_OPTION) {
//            System.out.println("Ke te drejte, sot eshte vape.");
//        } else if (ans == JOptionPane.CANCEL_OPTION) {
//            System.out.println("Te lutem pergjigju");
//        } else if (ans == JOptionPane.CLOSED_OPTION) {
//            System.out.println("Mirupafshim");
//        }
        //do pyeten 10 persona nese ata do votojne apo jo
        //ose thote YES, ose thote NO, ose shtyp x-in
        //
//        int cntYesVote = 0;
//        int cntNoVote = 0;
//        int cntNoAnsw = 0;
//
//        for (int i = 1; i <= 10; i++) {
//            int answer = JOptionPane.showConfirmDialog(null, "A do votosh",
//                    "Sondazh", JOptionPane.YES_NO_OPTION);
//            switch (answer) {
//                case JOptionPane.YES_OPTION:
//                    cntYesVote++;
//                    break;
//                case JOptionPane.NO_OPTION:
//                    cntNoVote++;
//                    break;
//                case JOptionPane.CLOSED_OPTION:
//                    cntNoAnsw++;
//                    break;
//            }
//        }
//
//        String message = (cntYesVote / 10.0 * 100) + "% do votojne "
//                + (cntNoVote / 10.0 * 100) + "% nuk do votojne "
//                + (cntNoAnsw / 10.0 * 100) + "% nuk u pergjigjen.";
//
//        JOptionPane.showMessageDialog(null, message, "Rezultati",
//                JOptionPane.INFORMATION_MESSAGE
//        );
        MyFrame frame = new MyFrame();
        frame.setVisible(true);

    }

}
