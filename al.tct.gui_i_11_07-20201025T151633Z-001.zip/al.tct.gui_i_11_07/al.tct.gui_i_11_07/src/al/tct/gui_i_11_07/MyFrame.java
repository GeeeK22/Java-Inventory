package al.tct.gui_i_11_07;

import javax.swing.*;

public class MyFrame extends JFrame {

    private static final int WIDTH = 300;
    private static final int HEIGHT = 500;

    private JPanel panel;
    private JLabel label;

    public MyFrame() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setSize(WIDTH, HEIGHT);
        setTitle("First GUI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        panel = new JPanel();
        label = new JLabel("Hello");
    }

    private void setUI() {
        panel.add(label);

        add(panel);
    }

}
