package al.tct.gui_ii_11_07;

public class Driver {

    public static void main(String[] args) {
      MyFrame frame = new MyFrame();
       frame.setVisible(true);

    //  MyFrame2 frame2 = new MyFrame2();
    // frame2.setVisible(true);
        //MyFrame3 frame3 = new MyFrame3();
        //frame3.setVisible(true);
    }

}
