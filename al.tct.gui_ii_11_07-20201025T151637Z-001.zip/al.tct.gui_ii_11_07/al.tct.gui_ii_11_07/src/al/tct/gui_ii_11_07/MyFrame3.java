package al.tct.gui_ii_11_07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyFrame3 extends JFrame {

    private static final int WIDTH = 250;
    private static final int HEIGHT = 200;

    private JPanel panel;

    private JLabel label1;
    private JLabel label2;
    private JLabel label3;

    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;

    private JButton buttonAdd;
    private JButton buttonMul;
    private JButton buttonDiv;
    private JButton buttonSub;
    private JButton buttonMod;
    private JButton buttonClear;

    public MyFrame3() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setSize(WIDTH, HEIGHT);
        setTitle("SWING Counter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        this.panel = new JPanel(new GridLayout(6, 2, 5, 0));

        this.label1 = new JLabel("First number: ");
        this.label2 = new JLabel("Second number: ");
        this.label3 = new JLabel("Result: ");

        this.textField1 = new JTextField(10);
        this.textField2 = new JTextField(10);
        this.textField3 = new JTextField(10);
        this.textField3.setEditable(false);

        MyActionListener listener = new MyActionListener();
        this.buttonAdd = new JButton("+");
        this.buttonAdd.addActionListener(listener);

        this.buttonMul = new JButton("*");
        this.buttonMul.addActionListener(listener);

        this.buttonDiv = new JButton("/");
        this.buttonDiv.addActionListener(listener);

        this.buttonSub = new JButton("-");
        this.buttonSub.setActionCommand("sub");
        this.buttonSub.addActionListener(listener);

        this.buttonMod = new JButton("%");
        this.buttonMod.addActionListener(listener);

        this.buttonClear = new JButton("CLEAR");
        //ky eshte objekt anonim
        //sepse nuk i ngjasohet MyActionListener
        this.buttonClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
            }
        });
    }

    private void setUI() {

        this.panel.add(this.label1);
        this.panel.add(this.textField1);
        this.panel.add(this.label2);
        this.panel.add(this.textField2);
        this.panel.add(this.label3);
        this.panel.add(this.textField3);

        this.panel.add(this.buttonAdd);
        this.panel.add(this.buttonSub);
        this.panel.add(this.buttonMul);
        this.panel.add(this.buttonDiv);
        this.panel.add(this.buttonMod);
        this.panel.add(this.buttonClear);

        add(this.panel);
    }

    private class MyActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            int number1 = Integer.parseInt(textField1.getText());
            int number2 = Integer.parseInt(textField2.getText());
            int result = 0;
            if (ae.getSource() == buttonAdd) {
                result = number1 + number2;
            } else if (ae.getSource() == buttonDiv) {
                result = number1 / number2;
            } else if (ae.getSource() == buttonMul) {
                result = number1 * number2;
            } else if (ae.getSource() == buttonSub) {
                result = number1 - number2;
            } else if (ae.getSource() == buttonMod) {
                result = number1 % number2;
            }
            textField3.setText(Integer.toString(result));
        }
    }

}
