package al.tct.gui_ii_11_07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyFrame extends JFrame {

    private static final int WIDTH = 400;
    private static final int HEIGHT = 200;

    private JPanel panel;

    private JLabel label;
    private JTextField textField;
    private JButton buttonUp;
    private JButton buttonDown;

    private int number = 0;

    public MyFrame() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setSize(WIDTH, HEIGHT);
        setTitle("SWING Counter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        panel = new JPanel();

        label = new JLabel("Counter");

        textField = new JTextField("0", 10);
        textField.setEditable(false);

        buttonUp = new JButton("Count up");
        //krijojme nje event te tipit ActionListener
        //duke krijuar nje klase anonime
        buttonUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number++;
                //merr numrin, konvertoje ne String
                //dhe vendose tek textField-i
                textField.setText(Integer.toString(number));
            }
        });

        buttonDown = new JButton("Count down");
        buttonDown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number--;
                textField.setText(Integer.toString(number));
            }
        });
    }

    private void setUI() {
        panel.add(label);
        panel.add(textField);
        panel.add(buttonUp);
        panel.add(buttonDown);

        add(panel);
    }

    //menyra e dyte per te krijuar nje event
    //te tpit ActionListener
    //duke krijuar nje klase private
    private class MyActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {

        }

    }

}
