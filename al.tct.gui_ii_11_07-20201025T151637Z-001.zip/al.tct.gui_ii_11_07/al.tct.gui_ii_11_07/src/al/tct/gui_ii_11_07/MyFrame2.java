package al.tct.gui_ii_11_07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyFrame2 extends JFrame {

    private static final int WIDTH = 300;
    private static final int HEIGHT = 100;

    private JPanel panel;
    private JLabel label1;
    private JTextField textFieldNumber;
    private JLabel label2;
    private JTextField textFieldSum;

    private int sum = 0;

    public MyFrame2() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setSize(WIDTH, HEIGHT);
        setTitle("SWING Counter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        panel = new JPanel();

        label1 = new JLabel("Enter an integer: ");

        textFieldNumber = new JTextField(10);
        textFieldNumber.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sNumber = textFieldNumber.getText();
                int number = Integer.parseInt(sNumber);
                sum = sum + number;
                textFieldSum.setText(Integer.toString(sum));
                textFieldNumber.setText("");
            }
        });

        label2 = new JLabel("Accumulated sum is: ");

        textFieldSum = new JTextField("0", 10);
        textFieldSum.setEditable(false);

    }

    private void setUI() {
        panel.add(label1);
        panel.add(textFieldNumber);
        panel.add(label2);
        panel.add(textFieldSum);

        add(panel);
    }

}
