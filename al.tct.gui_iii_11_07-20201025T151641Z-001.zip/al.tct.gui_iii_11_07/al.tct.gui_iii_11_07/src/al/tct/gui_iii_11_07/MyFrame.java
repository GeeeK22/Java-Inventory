package al.tct.gui_iii_11_07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class MyFrame extends JFrame {

    private static final int WIDTH = 400;
    private static final int HEIGHT = 75;

    private JPanel panel;

    private JLabel label1;
    private JPasswordField passwordField;
    private JButton button;
    private JLabel label2;
    private JTextField textField;
    private JLabel label3;

    private int randNumber;
    private int counter = 0;

    public MyFrame() {
        setProperties();
        init();
        setUI();
    }

    private void setProperties() {
        setTitle("SWING Calculator");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void init() {
        panel = new JPanel(new GridLayout(2, 3, 0, 5));
        label1 = new JLabel("The number is");
        passwordField = new JPasswordField();
        passwordField.setEditable(false);

        button = new JButton("Generate");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Random rand = new Random();
                randNumber = 1 + rand.nextInt(100);
                passwordField.setText("********");
                counter = 0;
                button.setEnabled(false);
                textField.setEditable(true);
                label3.setText("");
            }
        });

        label2 = new JLabel("Enter your guess");

        textField = new JTextField();
        textField.setEditable(false);
        textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sNumber = textField.getText();
                int number = Integer.parseInt(sNumber);

                String status = "";
                counter++;
                textField.setText("");

                if (number > randNumber) {
                    status = "Try lower!";
                } else if (number < randNumber) {
                    status = "Try higher!";
                } else {
                    status = "Bingo! (" + counter + ")";
                    button.setEnabled(true);
                    textField.setEditable(false);
                }
                label3.setText(status);
            }
        });

        label3 = new JLabel("");
    }

    private void setUI() {
        panel.add(label1);
        panel.add(passwordField);
        panel.add(button);
        panel.add(label2);
        panel.add(textField);
        panel.add(label3);

        add(panel);
    }

}
